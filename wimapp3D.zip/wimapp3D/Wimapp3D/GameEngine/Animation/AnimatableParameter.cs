﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameEngine
{
    class AnimatableParameter
    {
        private List<KeyFrame> KeyFramesList { get; set; }
        private SortedDictionary<double, KeyFrame> KeyFrames { get; set; }
        public AnimatableParameter()
        {
            KeyFrames = new SortedDictionary<double, KeyFrame>();
            
        }
        public double GetValueAtTime(double inTime)
        {
            double result = 0;
            List<double> indexList = new List<double>(KeyFrames.Keys);
            double number = 9;
            // 2 methodes om de dichtstbijzijnde index te vinden
            var closest = indexList.Where(numbers => numbers > number).First();
            var index = indexList.BinarySearch(number);
            if (KeyFrames.ContainsKey(index))
            {
                result = KeyFrames[index].Value;
            }

            return result;
        }
    }
}
