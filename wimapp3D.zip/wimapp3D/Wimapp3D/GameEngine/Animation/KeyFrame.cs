﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameEngine
{
    class KeyFrame
    {
        public double Value { get; set; }
        public KeyFrame(double inValue)
        {
            Value = inValue;
        }
    }
}
